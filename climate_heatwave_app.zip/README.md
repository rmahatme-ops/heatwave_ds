# Climate Intelligence — Heatwave Monitoring

A Streamlit dashboard for the supplied `heatwave_data.csv`, with a C linked-list module and Python stack/queue demonstrations.

## Dataset used

File: `heatwave_data.csv` (included in this folder)

The uploaded CSV contains 97,267 rows and these columns:
- `region` — IMD region
- `date` — date of observation
- `lat` — latitude
- `lon` — longitude
- `tmax` — maximum temperature

The file spans 2000-01-01 to 2024-12-31. There are 9 missing `tmax` values; rows with invalid/missing region, date or `tmax` are excluded from calculations. `lat` and `lon` are retained in the data table but are not used in the current calculations.

## Which dataset is used where?

| App feature | Dataset / columns | Purpose |
|---|---|---|
| Sidebar filters | `region`, `date` | Filter selected regions and date window |
| Dashboard metrics | filtered `tmax` | Count readings, mean Tmax, maximum Tmax, and threshold readings |
| Daily trend chart | `date`, `tmax` | Daily mean and maximum temperature |
| Region summary | `region`, `tmax` | Grouped readings, mean, and maximum by region |
| C linked-list analysis | filtered `tmax` values | C computes mean, maximum and count at/above threshold |
| Python stack demo | filtered `date`, `region`, `tmax` | Shows the latest 10 records in LIFO order |
| Python queue demo | records where `tmax >= threshold` | Shows up to 20 qualifying records in FIFO order |
| Filtered CSV tab/download | all CSV columns | Inspect and download filtered source rows |

## Data structures and syllabus mapping

- **C — Singly linked list / dynamic memory allocation:** `c/temperature_list.c`. One node per Tmax value, linked with `next`; allocated with `malloc` and released with `free`.
- **Python — Stack ADT:** `Stack` class in `app.py`; push/pop/peek, LIFO.
- **Python — Queue ADT:** `Queue` class in `app.py`; enqueue/dequeue, FIFO.
- **Python — Map/Dictionary:** dictionaries and `groupby` summaries associate region keys with their values.
- **Array/List:** temperature values are passed from Python to C as an array; stack uses a list internally.

This implementation intentionally does not claim to implement a B+ tree. The IA-2 report discusses a hash-table + B+ tree design, but that design is not implemented here. This version is a simpler teaching/demo app using concepts from the listed syllabus.

## Run locally

1. Install Python 3.10+.
2. Open a terminal in this folder.
3. Create/activate a virtual environment if desired.
4. Install packages:

   ```bash
   pip install -r requirements.txt
   ```
5. Run:

   ```bash
   streamlit run app.py
   ```

The app attempts to compile the C file with GCC when the Data Structures Lab tab is opened. If GCC is missing, the dashboard still works, but the C analysis panel will display a message. Install GCC to enable it.

## Deploy on Streamlit Community Cloud

1. Upload the contents of this folder to a GitHub repository.
2. In Streamlit Community Cloud, create an app from that repository.
3. Set the main file path to `app.py`.
4. Deploy.

The C panel requires a Linux-compatible `gcc` compiler in the deployment environment. If compilation is not available, the rest of the app remains usable.

## Important interpretation note

The threshold defaults to 40°C and can be changed. It is a project demonstration setting, not an official IMD heatwave definition or an official alert. This app analyzes historical readings; it does not predict future temperatures.
